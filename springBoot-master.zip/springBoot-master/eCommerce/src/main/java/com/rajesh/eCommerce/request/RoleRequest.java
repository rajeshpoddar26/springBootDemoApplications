package com.rajesh.eCommerce.request;

import lombok.Data;

@Data
public class RoleRequest {

	private String roleName;
	private String roleDiscription;
}
