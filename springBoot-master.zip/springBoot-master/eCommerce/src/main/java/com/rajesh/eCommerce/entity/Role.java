package com.rajesh.eCommerce.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "ROLE")
@Data
public class Role {

	@Id
//	@GeneratedValue(generator = "uuid")
//	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ROLE_NAME")
	private String roleName;
	@Column(name = "ROLE_DISCRIPTION")
	private String roleDiscription;
}
