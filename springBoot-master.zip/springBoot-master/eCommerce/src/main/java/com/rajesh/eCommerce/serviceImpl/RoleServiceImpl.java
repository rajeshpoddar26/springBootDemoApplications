package com.rajesh.eCommerce.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rajesh.eCommerce.entity.Role;
import com.rajesh.eCommerce.repository.RoleRepository;
import com.rajesh.eCommerce.request.RoleRequest;
import com.rajesh.eCommerce.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleRepository roleRepository;

	@Override
	public Object createNewRole(RoleRequest request) {
		
		Role role = new Role();
		role.setRoleName(request.getRoleName());
		role.setRoleDiscription(request.getRoleDiscription());
		
		return roleRepository.save(role);
	}

}
