package com.rajesh.eCommerce.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.rajesh.eCommerce.entity.JwtRequest;


public interface JwtService extends UserDetailsService{

	Object createJwtToken(JwtRequest jwtRequest) throws Exception;

}
