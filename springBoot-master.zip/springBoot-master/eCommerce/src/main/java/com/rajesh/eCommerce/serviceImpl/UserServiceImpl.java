package com.rajesh.eCommerce.serviceImpl;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.rajesh.eCommerce.entity.Role;
import com.rajesh.eCommerce.entity.User;
import com.rajesh.eCommerce.repository.RoleRepository;
import com.rajesh.eCommerce.repository.UserRepository;
import com.rajesh.eCommerce.request.UserRequest;
import com.rajesh.eCommerce.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public Object registerNewUser(UserRequest request) {
		return null;
	}

	@Override
	public void initRolesAndUsers() {

//		creating Role hear
		Role adminRole = new Role();
		adminRole.setRoleName("ADMIN");
		adminRole.setRoleDiscription("Admin Role");

		roleRepository.save(adminRole);

		Role userRole = new Role();
		userRole.setRoleName("USER");
		userRole.setRoleDiscription("Default role for newly created User");

		roleRepository.save(userRole);

//		Setting role to the User
		User adminUser = new User();
		adminUser.setUserName("AdminUser");
		adminUser.setFirstName("Admin");
		adminUser.setLastName("AdminLast");
		adminUser.setPassword(getPasswordEncoded("admin123"));

		Set<Role> adminRoles = new HashSet<>();
		adminRoles.add(adminRole);
		adminUser.setRole(adminRoles);

		userRepository.save(adminUser);

//		Setting role to the User
		User user = new User();
		user.setUserName("DefaultUser");
		user.setFirstName("Rajesh");
		user.setLastName("Kumar");
		user.setPassword(getPasswordEncoded("rajesh123"));

		Set<Role> userRoles = new HashSet<>();
		userRoles.add(userRole);
		user.setRole(userRoles);

		userRepository.save(user);

	}

	public String getPasswordEncoded(String password) {
		return passwordEncoder.encode(password);
	}

}
