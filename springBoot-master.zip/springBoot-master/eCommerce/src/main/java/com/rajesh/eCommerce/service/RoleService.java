package com.rajesh.eCommerce.service;

import com.rajesh.eCommerce.request.RoleRequest;

public interface RoleService {

	public Object createNewRole(RoleRequest request); 
}
