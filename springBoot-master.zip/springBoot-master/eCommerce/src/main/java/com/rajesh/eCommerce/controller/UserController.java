package com.rajesh.eCommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rajesh.eCommerce.request.UserRequest;
import com.rajesh.eCommerce.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/createNewUser")
	public Object registerNewUser(@RequestBody UserRequest request) {

		return userService.registerNewUser(request);
	}

	@PostMapping("/")
	public void initRolesAndUsers() {
		userService.initRolesAndUsers();
	}

	@GetMapping("/forUser")
	public Object forUser() {
		return "This url for user";
	}

	@GetMapping("/forAdmin")
	public Object forAdmin() {
		return "This url for admin";
	}
}
