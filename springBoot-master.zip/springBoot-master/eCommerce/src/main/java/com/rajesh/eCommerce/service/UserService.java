package com.rajesh.eCommerce.service;

import com.rajesh.eCommerce.request.UserRequest;

public interface UserService {

	Object registerNewUser(UserRequest request);
	
	void initRolesAndUsers();

}
